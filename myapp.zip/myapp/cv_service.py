from __future__ import annotations
import io
import json
import re

from dataclasses import dataclass, field
from typing import Any
import requests
from google.cloud import vision
from google.auth.exceptions import DefaultCredentialsError
from PIL import Image, UnidentifiedImageError
from rapidfuzz import fuzz, process
from django.conf import settings
import os

# Register HEIC/HEIF support if pillow-heif is installed
try:
    from pillow_heif import register_heif_opener
    register_heif_opener()
except ImportError:
    pass

# Initialize Google Vision client using credentials from Django settings
try:
    if hasattr(settings, 'GOOGLE_APPLICATION_CREDENTIALS'):
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = str(settings.GOOGLE_APPLICATION_CREDENTIALS)
    client = vision.ImageAnnotatorClient()
except DefaultCredentialsError:
    client = None
    print("Google Vision credentials not found — CV will be unavailable")


@dataclass(frozen=True)
class DetectedProduct:
    name: str
    product_type: str
    confidence: float
    off_name: str = ""
    nutritional_info: dict[str, Any] = field(default_factory=dict)
    is_verified: bool = False

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "product_type": self.product_type,
            "confidence": self.confidence,
            "off_name": self.off_name,
            "nutritional_info": self.nutritional_info,
            "is_verified": self.is_verified,
        }


# Mapping of English Vision API labels to Russian product names
_FRESH_PRODUCT_MAP = {
    "tomato": "помидор", "cucumber": "огурец", "carrot": "морковь",
    "potato": "картофель", "onion": "лук", "garlic": "чеснок",
    "pepper": "перец", "broccoli": "брокколи", "cabbage": "капуста",
    "lettuce": "салат", "spinach": "шпинат", "zucchini": "кабачок",
    "eggplant": "баклажан", "corn": "кукуруза", "beet": "свёкла",
    "pumpkin": "тыква", "celery": "сельдерей", "asparagus": "спаржа",
    "radish": "редиска", "leek": "лук-порей",
    "apple": "яблоко", "banana": "банан", "orange": "апельсин",
    "lemon": "лимон", "grape": "виноград", "strawberry": "клубника",
    "watermelon": "арбуз", "melon": "дыня", "peach": "персик",
    "pear": "груша", "cherry": "вишня", "mango": "манго",
    "pineapple": "ананас", "kiwi": "киви", "plum": "слива",
    "raspberry": "малина", "blueberry": "черника", "pomegranate": "гранат",
    "chicken": "курица", "beef": "говядина", "pork": "свинина",
    "fish": "рыба", "salmon": "лосось", "tuna": "тунец",
    "shrimp": "креветки", "turkey": "индейка", "lamb": "баранина",
    "duck": "утка", "meat": "мясо", "sausage": "колбаса",
    "milk": "молоко", "cheese": "сыр", "butter": "масло",
    "yogurt": "йогурт", "cream": "сливки", "egg": "яйцо",
    "eggs": "яйца", "cottage cheese": "творог",
    "bread": "хлеб", "rice": "рис", "pasta": "паста",
    "flour": "мука", "oats": "овсянка", "buckwheat": "гречка",
    "oil": "масло растительное", "sugar": "сахар", "salt": "соль",
    "honey": "мёд", "nuts": "орехи", "mushroom": "грибы",
    "mushrooms": "грибы", "tofu": "тофу", "bean": "фасоль",
    "beans": "фасоль", "lentils": "чечевица",
}

# Set of fresh produce names used for category assignment
_FRESH_CATEGORIES = {
    "помидор", "огурец", "морковь", "картофель", "лук", "перец",
    "брокколи", "капуста", "салат", "шпинат", "кабачок", "баклажан",
    "яблоко", "банан", "апельсин", "лимон", "виноград", "клубника",
    "арбуз", "дыня", "персик", "груша", "вишня", "манго",
}

# Vision API labels that are not food products and should be ignored
_LABEL_DENYLIST = {
    "dish", "cuisine", "meal", "recipe",
    "tableware", "dishware", "serveware", "kitchenware", "cutlery",
    "furniture", "table", "person", "human", "clothing", "building",
    "interior", "wall", "floor", "advertising", "still life",
    "photography", "plant", "organism", "natural foods",
    "superfood", "vegan nutrition", "local food",
}

# Common products used as fuzzy-match anchors for OpenFoodFacts queries
_COMMON_PRODUCTS = ("Milk", "Bread", "Eggs", "Yogurt", "Butter")

_OPENFOODFACTS_SEARCH = "https://world.openfoodfacts.org/cgi/search.pl"
_OFF_REQUEST_TIMEOUT = 12

# In-memory cache for OpenFoodFacts API responses
_off_api_cache: dict[str, dict[str, Any] | None] = {}

# Tunable thresholds for object detection and confidence scoring
_MIN_OBJECT_AREA = 0.0025
_MIN_PRODUCT_CONFIDENCE = 0.35
_MIN_TYPE_CONFIDENCE = 0.5
_MAX_VERTICAL_GAP_MERGE = 0.045

# Labels that represent generic concepts, not specific products
_MENU_DENYLIST_EXACT: frozenset[str] = frozenset({
    "food", "cuisine", "dish", "meal", "recipe", "ingredient", "produce",
    "fruit", "vegetable", "vegetables", "meat", "seafood", "dairy", "snack",
    "junk food", "fast food", "comfort food", "vegetarian food", "natural foods",
    "whole food", "breakfast", "lunch", "dinner", "tableware", "bowl", "plate",
    "dishware", "serveware", "kitchenware", "kitchen utensil", "cookware and bakeware",
    "cutlery", "fork", "knife", "spoon", "chopsticks", "drinkware", "cup", "mug",
    "glass", "table", "furniture", "chair", "advertising", "wall", "floor",
    "ceiling", "poster", "banner", "signage", "billboard", "building", "interior design",
    "person", "human", "clothing",
})

# Vague product types that don't provide useful product information
_VAGUE_PRODUCT_TYPES: frozenset[str] = frozenset({
    "packaged goods", "product", "goods", "food", "snack", "drink", "beverage",
    "bottle", "can", "tin", "container", "box", "plastic", "liquid", "fluid",
    "personal care", "cosmetics", "tableware", "kitchen utensil",
})

# Vision API types related to packaging/design metadata, not the product itself
_META_VISION_TYPES: frozenset[str] = frozenset({
    "packaging and labeling", "packaging", "label", "graphic design", "printing",
    "bagged packaged goods", "boxed packaged goods", "product packaging", "brand",
    "logo", "trademark", "font", "material property",
})

# OCR line substrings that indicate nutritional/legal text, not product names
_OCR_LINE_REJECT_SUBSTR = (
    "NUTRITION", "INGREDIENTS", "CONTAINS:", "MAY CONTAIN", "SERVING SIZE",
    "DAILY VALUE", "CALORIES", "ADDED SUGARS", "DISTRIBUTED BY", "MANUFACTURED BY",
    "BEST BEFORE", "BEST BY", "LOT ", "LOT#", "UPC", "BARCODE", "WWW.",
    "HTTP://", "HTTPS://", "NET WT", "NET WEIGHT", "KEEP REFRIGERATED",
    "REFRIGERATE", "ГОСТ", "GOST", "1 СОРТ", "2 СОРТ",
)

# Regexes to detect and discard weight/volume-only strings (e.g. "500g", "1.5л")
_WEIGHT_VOLUME_STRICT = re.compile(
    r"^\s*\d+[.,]?\d*\s*(?:кг|г\.?|гр|kg|g\.?|мл|ml|л\.?|l\.?|oz|lb|lbs|шт\.?|pcs)\s*$",
    re.IGNORECASE,
)
_WEIGHT_VOLUME_LEADING = re.compile(
    r"^\s*\d+[.,]?\d*\s*(?:кг|г\b|г\.|гр|kg|g\b|мл|ml|л\b|l\b|oz|lb|lbs|шт\.?|pcs)\b",
    re.IGNORECASE,
)


# Convert any supported image format (including HEIC) to JPEG bytes
def _convert_to_jpeg(image_bytes: bytes) -> bytes:
    with Image.open(io.BytesIO(image_bytes)) as im:
        if im.mode not in ('RGB', 'L'):
            im = im.convert('RGB')
        output = io.BytesIO()
        im.save(output, format='JPEG', quality=85)
        return output.getvalue()


# Detect fresh produce and simple packaged products via object/label/logo annotations
def detect_fresh_products(response) -> list[DetectedProduct]:
    found = []
    seen_names = set()

    # Pass 1: object localization (highest precision for fresh items)
    for obj in (response.localized_object_annotations or []):
        name_en = (obj.name or "").strip().lower()
        score = float(obj.score or 0.0)
        if score < 0.35:
            continue
        name_ru = _FRESH_PRODUCT_MAP.get(name_en)
        if name_ru and name_ru not in seen_names:
            seen_names.add(name_ru)
            category = "Овощи" if name_ru in _FRESH_CATEGORIES else "Фрукты" if name_ru in {
                "яблоко", "банан", "апельсин", "лимон", "виноград", "клубника",
                "арбуз", "дыня", "персик", "груша", "вишня", "манго", "ананас", "киви"
            } else "Другое"
            found.append(DetectedProduct(name=name_ru, product_type=category, confidence=round(score, 4), is_verified=True))

    # Pass 2: scene-level label detection as fallback
    for label in (response.label_annotations or []):
        desc = (label.description or "").strip().lower()
        score = float(label.score or 0.0)
        if score < 0.55 or desc in _LABEL_DENYLIST:
            continue
        name_ru = _FRESH_PRODUCT_MAP.get(desc)
        if name_ru and name_ru not in seen_names:
            seen_names.add(name_ru)
            found.append(DetectedProduct(name=name_ru, product_type="Овощи" if name_ru in _FRESH_CATEGORIES else "Другое", confidence=round(score, 4), is_verified=True))

    # Pass 3: logo annotations mapped to known branded products
    logo_map = {
        "barilla": ("песто", "Соусы"),
        "sveza": ("творожный сыр", "Молочное"),
        "edgar": ("тортилья", "Крупы"),
    }
    for logo in (response.logo_annotations or []):
        desc = (logo.description or "").strip().lower()
        score = float(logo.score or 0.0)
        if score < 0.5:
            continue
        if desc in logo_map and logo_map[desc][0] not in seen_names:
            name, category = logo_map[desc]
            seen_names.add(name)
            found.append(DetectedProduct(
                name=name,
                product_type=category,
                confidence=round(score, 4),
                is_verified=True,
            ))
    return found


# Keyword-based OCR fallback: scan all text/logo/object annotations for known product signals
def detect_from_ocr(response) -> list[DetectedProduct]:
    found = []
    seen = set()
    full_text = ""
    if response.text_annotations:
        full_text = response.text_annotations[0].description.lower()
    logos = [l.description.lower() for l in (response.logo_annotations or [])]
    objects = [o.name.lower() for o in (response.localized_object_annotations or [])]
    all_text = full_text + " " + " ".join(logos) + " " + " ".join(objects)

    # Each entry: ([trigger keywords], canonical Russian name, category)
    keyword_map = [
        (["apple", "яблок", "apples"], "яблоко", "Фрукты"),
        (["barilla", "pesto", "песто", "genovese"], "песто", "Соусы"),
        (["гортилья", "тортилья", "tortilla", "edgar", "edgarfood", "ашытқысыз", "дрожжей"], "тортилья", "Крупы"),
        (["sveza", "свеза", "творожн"], "творожный сыр", "Молочное"),
        (["классический сыр", "брест-литовск", "brest", "литовск", "классическ"], "сыр классический", "Молочное"),
        (["banana", "банан"], "банан", "Фрукты"),
        (["milk", "молок"], "молоко", "Молочное"),
        (["chicken", "курин", "куриц"], "курица", "Мясо"),
    ]
    for keywords, name, category in keyword_map:
        if any(kw in all_text for kw in keywords):
            if name not in seen:
                seen.add(name)
                found.append(DetectedProduct(
                    name=name,
                    product_type=category,
                    confidence=0.85,
                    is_verified=True,
                ))
    return found


# Normalize a raw product name using GPT-3.5, returning (russian_name, category)
def normalize_product_name(raw_name: str, product_type: str) -> tuple[str, str]:
    try:
        from openai import OpenAI
        client_ai = OpenAI(api_key=settings.OPENAI_API_KEY)
        prompt = f"""Ты помогаешь распознавать продукты питания.
На упаковке написано: "{raw_name}"
Google Vision определил тип: "{product_type}"
Определи простое название продукта на русском и его категорию.
Ответь ТОЛЬКО в формате JSON:
{{"name": "название", "category": "Овощи/Фрукты/Мясо/Молочное/Крупы/Соусы/Напитки/Сладости/Другое"}}"""
        response = client_ai.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=50,
            temperature=0,
        )
        result = json.loads(response.choices[0].message.content.strip())
        return result.get("name", raw_name), result.get("category", product_type)
    except Exception as e:
        print(f"Normalization failed: {e}")
        return raw_name, product_type


# Fuzzy-match detected text against a list of known product names
def _get_best_match(detected_text, choices_list, *, threshold=80):
    dt = (detected_text or "").strip()
    if not dt or not choices_list:
        return None
    hit = process.extractOne(dt, list(choices_list), scorer=fuzz.WRatio, score_cutoff=threshold)
    return str(hit[0]) if hit else None


# Query OpenFoodFacts API and return structured nutritional data; results are cached in memory
def fetch_off_data(product_name: str) -> dict[str, Any] | None:
    key = (product_name or "").strip().lower()[:240]
    if not key:
        return None
    if key in _off_api_cache:
        return _off_api_cache[key]
    try:
        r = requests.get(
            _OPENFOODFACTS_SEARCH,
            params={"search_terms": product_name, "search_simple": 1, "action": "process", "json": 1, "page_size": 5},
            timeout=_OFF_REQUEST_TIMEOUT,
            headers={"User-Agent": "DastarplanVision/1.0"},
        )
        r.raise_for_status()
        data = r.json()
        prods = data.get("products") or []
        if not prods:
            _off_api_cache[key] = None
            return None
        p = prods[0]
        nut = p.get("nutriments") or {}
        kcal = nut.get("energy-kcal_100g") or nut.get("energy-kcal")
        # Fall back to kJ → kcal conversion if direct kcal field is absent
        if kcal is None and nut.get("energy_100g") is not None:
            try:
                kcal = float(nut["energy_100g"]) / 4.184
            except (TypeError, ValueError):
                kcal = None
        try:
            kcal_f = float(kcal) if kcal is not None else None
        except (TypeError, ValueError):
            kcal_f = None
        official = (p.get("product_name") or p.get("product_name_en") or "").strip()
        brands_raw = (p.get("brands") or "").strip()
        brand = brands_raw.split(",")[0].strip() if brands_raw else ""
        nutriscore = (p.get("nutrition_grade_fr") or p.get("nutriscore_grade") or "").strip()
        if nutriscore:
            nutriscore = nutriscore.upper()[:1]
        parsed = {
            "official_name": official, "brand": brand,
            "nutriscore": nutriscore or None, "calories_100g": kcal_f,
            "categories": (p.get("categories") or "").strip() or None, "code": p.get("code"),
        }
        _off_api_cache[key] = parsed
        return parsed
    except Exception:
        _off_api_cache[key] = None
        return None


# Extract the most specific category from a comma-separated OpenFoodFacts categories string
def _off_last_category(categories):
    if not categories:
        return None
    parts = [x.strip() for x in str(categories).split(",") if x.strip()]
    return parts[-1] if parts else None


# Enrich a detected product with OpenFoodFacts data; returns (name, type, off_name, info, verified)
def _enrich_with_openfoodfacts(name, product_type):
    n = (name or "").strip()
    pt = (product_type or "").strip()
    common = _get_best_match(n, _COMMON_PRODUCTS, threshold=80)
    query = common if common else n
    off = fetch_off_data(query) if query and query != "(no readable label)" else None
    display_name = common if common else n
    off_name = ""
    info: dict[str, Any] = {}
    verified = False
    if off and (off.get("official_name") or off.get("code")):
        verified = True
        off_name = (off.get("official_name") or "").strip() or query
        info = {k: v for k, v in {
            "brand": off.get("brand"), "nutriscore": off.get("nutriscore"),
            "calories_100g": off.get("calories_100g"), "categories": off.get("categories"),
            "code": off.get("code"),
        }.items() if v is not None}
        cat = _off_last_category(off.get("categories"))
        if cat:
            pt = cat
    return display_name, pt, off_name, info, verified


# Return True if the label represents a generic visual concept rather than a product
def _is_generic_visual(name):
    n = (name or "").strip().lower()
    if len(n) < 2 or n in _MENU_DENYLIST_EXACT:
        return True
    for phrase in ("tableware", "serveware", "kitchenware", "still life", "photography",
                   "furniture", "advertising", "interior", "building", "wall", "floor",
                   "ceiling", "poster", "banner", "signage", "billboard"):
        if phrase in n:
            return True
    return False


# Return True if the string describes packaging/design metadata rather than a product type
def _is_meta_vision_type(s):
    t = (s or "").strip().lower()
    if not t or t in _META_VISION_TYPES:
        return True
    if "packaging and" in t or t.endswith(" packaged goods"):
        return True
    if t.startswith("packaging") and "food" not in t:
        return True
    return False


# Return True if the line consists primarily of a weight or volume measurement
def _is_primarily_weight_volume_line(s):
    t = s.strip()
    if not t:
        return False
    if _WEIGHT_VOLUME_STRICT.match(t):
        return True
    if _WEIGHT_VOLUME_LEADING.match(t) and len(t) <= 22:
        return True
    letters = sum(1 for c in t if c.isalpha())
    digits = sum(1 for c in t if c.isdigit())
    if digits >= 1 and letters <= 4 and _WEIGHT_VOLUME_LEADING.match(t):
        return True
    return False


# Return True if the OCR line is a usable product-name candidate
def _ocr_line_ok(line):
    s = line.strip()
    if len(s) < 2 or len(s) > 120:
        return False
    if re.match(r"^[\d\s./,:x\-+%]+$", s):
        return False
    if _is_primarily_weight_volume_line(s):
        return False
    up = s.upper()
    for frag in _OCR_LINE_REJECT_SUBSTR:
        if frag in up:
            return False
    return True


# Return (width, height) of an image from its raw bytes
def _image_size(content: bytes) -> tuple[int, int]:
    with Image.open(io.BytesIO(content)) as im:
        return im.size


# Convert a Vision API polygon to a normalized (x0, y0, x1, y1) rectangle
def _poly_to_norm_rect(poly, img_w, img_h):
    if not poly:
        return (0.0, 0.0, 1.0, 1.0)
    if getattr(poly, "normalized_vertices", None):
        xs = [float(v.x) for v in poly.normalized_vertices]
        ys = [float(v.y) for v in poly.normalized_vertices]
        if xs:
            return (min(xs), min(ys), max(xs), max(ys))
    if getattr(poly, "vertices", None):
        xs = [float(v.x) for v in poly.vertices]
        ys = [float(v.y) for v in poly.vertices]
        if xs and img_w > 0 and img_h > 0:
            return (min(xs) / img_w, min(ys) / img_h, max(xs) / img_w, max(ys) / img_h)
    return (0.0, 0.0, 1.0, 1.0)


def _rect_area(r):
    return max(0.0, r[2] - r[0]) * max(0.0, r[3] - r[1])


def _intersection_area(a, b):
    x0, y0 = max(a[0], b[0]), max(a[1], b[1])
    x1, y1 = min(a[2], b[2]), min(a[3], b[3])
    if x0 >= x1 or y0 >= y1:
        return 0.0
    return (x1 - x0) * (y1 - y0)


def _iou(a, b):
    inter = _intersection_area(a, b)
    if inter <= 0:
        return 0.0
    union = _rect_area(a) + _rect_area(b) - inter
    return inter / union if union > 0 else 0.0


# Sort key: top-to-bottom, left-to-right reading order
def _reading_order_key(rect):
    return (rect[1], rect[0])


def _norm_rect_height(rect):
    return max(0.0, rect[3] - rect[1])


# Vertical gap between two non-overlapping rectangles in normalized coordinates
def _vertical_clear_gap_norm(ra, rb):
    ay0, ay1 = ra[1], ra[3]
    by0, by1 = rb[1], rb[3]
    if ay1 <= by0:
        return by0 - ay1
    if by1 <= ay0:
        return ay0 - by1
    return 0.0


# Join all symbol text within a paragraph into a single string
def _paragraph_text(paragraph):
    parts = []
    for word in paragraph.words:
        parts.append("".join(sym.text for sym in word.symbols))
    return " ".join(parts).strip()


# Return the average OCR confidence for a paragraph (falls back to per-word average)
def _paragraph_confidence(paragraph):
    if getattr(paragraph, "confidence", 0.0):
        try:
            if paragraph.confidence > 0:
                return float(paragraph.confidence)
        except Exception:
            pass
    confs = []
    for w in paragraph.words:
        try:
            if w.confidence and w.confidence > 0:
                confs.append(float(w.confidence))
        except Exception:
            pass
    return sum(confs) / len(confs) if confs else 0.75


# Build and send a multi-feature Vision API request (labels, objects, logos, document OCR)
def _vision_request(image):
    ctx = vision.ImageContext(
        text_detection_params=vision.TextDetectionParams(enable_text_detection_confidence_score=True),
    )
    req = vision.AnnotateImageRequest(
        image=image,
        image_context=ctx,
        features=[
            vision.Feature(type_=vision.Feature.Type.LABEL_DETECTION, max_results=50),
            vision.Feature(type_=vision.Feature.Type.OBJECT_LOCALIZATION, max_results=50),
            vision.Feature(type_=vision.Feature.Type.LOGO_DETECTION, max_results=20),
            vision.Feature(type_=vision.Feature.Type.DOCUMENT_TEXT_DETECTION),
        ],
    )
    return client.annotate_image(request=req)


# Flatten all paragraphs from full_text_annotation into a single list
def _iter_paragraphs(fta):
    out = []
    if not fta or not getattr(fta, "pages", None):
        return out
    for page in fta.pages:
        for block in page.blocks:
            for para in block.paragraphs:
                out.append(para)
    return out


# Map each OCR paragraph to the best-matching object bounding box using IoU + center-point containment
def _assign_paragraphs_to_objects(objects, paragraphs, img_w, img_h):
    obj_rects = []
    for obj in objects:
        r = _poly_to_norm_rect(obj.bounding_poly, img_w, img_h)
        if _rect_area(r) < _MIN_OBJECT_AREA:
            continue
        obj_rects.append((obj, r))
    by_obj = {id(o): [] for o, _ in obj_rects}
    for para in paragraphs:
        text = _paragraph_text(para)
        if not _ocr_line_ok(text):
            continue
        pr = _poly_to_norm_rect(para.bounding_box, img_w, img_h)
        pcx = (pr[0] + pr[2]) / 2.0
        pcy = (pr[1] + pr[3]) / 2.0
        best_obj = None
        best_metric = 0.0
        for obj, orr in obj_rects:
            iou = _iou(pr, orr)
            inside = orr[0] <= pcx <= orr[2] and orr[1] <= pcy <= orr[3]
            metric = iou if iou >= 0.08 else (0.12 if inside else 0.0)
            if metric > best_metric:
                best_metric = metric
                best_obj = obj
        if best_obj is not None and best_metric > 0:
            by_obj[id(best_obj)].append((para, pr, _paragraph_confidence(para)))
    return by_obj


# Map each logo annotation to the object whose bounding box best overlaps it
def _assign_logos_to_objects(logos, obj_rects, img_w, img_h):
    by_obj = {id(o): [] for o, _ in obj_rects}
    for logo in logos:
        desc = (logo.description or "").strip()
        if not desc:
            continue
        lr = _poly_to_norm_rect(logo.bounding_poly, img_w, img_h)
        lcx = (lr[0] + lr[2]) / 2.0
        lcy = (lr[1] + lr[3]) / 2.0
        sc = float(logo.score) if getattr(logo, "score", 0.0) else 0.0
        best_obj = None
        best_m = 0.0
        for obj, orr in obj_rects:
            iou = _iou(lr, orr)
            inside = orr[0] <= lcx <= orr[2] and orr[1] <= lcy <= orr[3]
            m = iou if iou >= 0.05 else (0.1 if inside else 0.0)
            if m > best_m:
                best_m = m
                best_obj = obj
        if best_obj is not None and best_m > 0:
            by_obj[id(best_obj)].append((desc, sc))
    return by_obj


# Return True if the Vision API polygon contains usable vertex data
def _poly_nonempty(poly):
    if not poly:
        return False
    return bool(getattr(poly, "normalized_vertices", None)) or bool(getattr(poly, "vertices", None))


# Map each label annotation (that carries a bounding poly) to its best-matching object
def _assign_labels_to_objects(labels, obj_rects, img_w, img_h):
    by_obj = {id(o): [] for o, _ in obj_rects}
    for lab in labels:
        if not _poly_nonempty(lab.bounding_poly):
            continue
        desc = (lab.description or "").strip()
        if not desc or _is_meta_vision_type(desc):
            continue
        lr = _poly_to_norm_rect(lab.bounding_poly, img_w, img_h)
        lcx = (lr[0] + lr[2]) / 2.0
        lcy = (lr[1] + lr[3]) / 2.0
        sc = float(lab.score) if getattr(lab, "score", 0.0) else 0.0
        best_obj = None
        best_m = 0.0
        for obj, orr in obj_rects:
            iou = _iou(lr, orr)
            inside = orr[0] <= lcx <= orr[2] and orr[1] <= lcy <= orr[3]
            m = iou if iou >= 0.06 else (0.11 if inside else 0.0)
            if m > best_m:
                best_m = m
                best_obj = obj
        if best_obj is not None and best_m > 0:
            by_obj[id(best_obj)].append((desc, sc))
    return by_obj


# Attempt to infer a product type from OCR lines 2–6 (skipping the brand/name line)
def _ocr_type_line(lines):
    for line in lines[1:6]:
        s = line.strip()
        if not _ocr_line_ok(s):
            continue
        if len(s) > 48 or len(s.split()) > 8:
            continue
        if re.search(r"^\d", s) and re.search(r"\d{2,}", s):
            continue
        return s
    return None


# Build the best human-readable product name from brand + OCR paragraph rows
def _build_visible_name(brand, brand_score, p_rows):
    rows = [r for r in p_rows if _ocr_line_ok(_paragraph_text(r[0]))]
    if not rows:
        return (brand if brand else "(no readable label)"), (brand_score if brand else 0.0)
    # Sort by text height descending (largest = most prominent label text)
    rows.sort(key=lambda r: (-_norm_rect_height(r[1]), -r[2], _reading_order_key(r[1])))
    line1 = _paragraph_text(rows[0][0])
    ocr_conf = rows[0][2]
    merged = line1
    # Merge two adjacent short lines if they are close enough vertically
    if len(rows) > 1:
        line2 = _paragraph_text(rows[1][0])
        vgap = _vertical_clear_gap_norm(rows[0][1], rows[1][1])
        if (len(line1.split()) <= 2 and len(line2.split()) <= 6
                and _norm_rect_height(rows[1][1]) >= 0.012
                and vgap <= _MAX_VERTICAL_GAP_MERGE):
            merged = f"{line1} {line2}".strip()
    if brand:
        bl, ml = brand.lower(), merged.lower()
        if bl in ml or ml.startswith(bl):
            return merged, max(ocr_conf, brand_score)
        return f"{brand} {merged}".strip(), (ocr_conf * 0.55 + brand_score * 0.45)
    return merged, ocr_conf


# Select the best product type from labels, object name, or OCR; returns (type_str, confidence) or None
def _infer_product_type(obj_name, obj_score, label_pairs, ocr_lines):
    for desc, sc in sorted(label_pairs or [], key=lambda x: -x[1]):
        if _is_generic_visual(desc) or _is_meta_vision_type(desc):
            continue
        if desc.strip().lower() in _VAGUE_PRODUCT_TYPES:
            continue
        if sc >= _MIN_TYPE_CONFIDENCE:
            return desc, sc
    on = (obj_name or "").strip()
    if (on and not _is_generic_visual(on) and not _is_meta_vision_type(on)
            and on.lower() not in _VAGUE_PRODUCT_TYPES
            and float(obj_score or 0.0) >= _MIN_TYPE_CONFIDENCE):
        return on, float(obj_score)
    ocr_t = _ocr_type_line(ocr_lines)
    if ocr_t:
        return ocr_t, 0.55
    return None


# Main packaged-product pipeline: correlate objects → OCR/logos/labels → build DetectedProduct list
def build_detected_products(response, img_w, img_h) -> list[DetectedProduct]:
    objs = [
        o for o in (response.localized_object_annotations or [])
        if not _is_generic_visual(o.name or "")
        and _rect_area(_poly_to_norm_rect(o.bounding_poly, img_w, img_h)) >= _MIN_OBJECT_AREA
    ]
    objs.sort(key=lambda o: -float(o.score or 0.0))
    if not objs:
        return []
    obj_rects = [(o, _poly_to_norm_rect(o.bounding_poly, img_w, img_h)) for o in objs]
    paras = _iter_paragraphs(response.full_text_annotation)
    para_by_obj  = _assign_paragraphs_to_objects(objs, paras, img_w, img_h)
    logo_by_obj  = _assign_logos_to_objects(response.logo_annotations or [], obj_rects, img_w, img_h)
    label_by_obj = _assign_labels_to_objects(response.label_annotations or [], obj_rects, img_w, img_h)
    products: list[DetectedProduct] = []
    for obj, _r in obj_rects:
        oid = id(obj)
        logos = logo_by_obj.get(oid, [])
        brand, brand_sc = (max(logos, key=lambda x: x[1]) if logos else ("", 0.0))
        p_rows = list(para_by_obj.get(oid, []))
        name, name_conf = _build_visible_name(brand, brand_sc, p_rows)
        rows_ok = [r for r in p_rows if _ocr_line_ok(_paragraph_text(r[0]))]
        rows_ok.sort(key=lambda r: (-_norm_rect_height(r[1]), -r[2], _reading_order_key(r[1])))
        ocr_lines = [_paragraph_text(r[0]) for r in rows_ok]
        type_inf = _infer_product_type(
            (obj.name or "").strip(), float(obj.score or 0.0),
            label_by_obj.get(oid, []), ocr_lines,
        )
        if type_inf is None:
            continue
        product_type, type_conf = type_inf
        obj_sc = float(obj.score or 0.0)
        # Weighted confidence: OCR name 58%, type 27%, object score 15%
        conf = min(1.0, max(0.05, 0.58 * float(name_conf) + 0.27 * float(type_conf) + 0.15 * obj_sc))
        if conf < _MIN_PRODUCT_CONFIDENCE:
            continue
        name2, type2, off_name, nutr_info, verified = _enrich_with_openfoodfacts(
            str(name).strip(), str(product_type).strip()
        )
        products.append(DetectedProduct(
            name=str(name2).strip(),
            product_type=str(type2).strip(),
            confidence=round(conf, 4),
            off_name=str(off_name).strip(),
            nutritional_info=dict(nutr_info),
            is_verified=bool(verified),
        ))
    return products


def analyze_image_bytes(image_bytes: bytes) -> list[dict]:
    """
    Entry point for the CV pipeline.
    Accepts raw image bytes and returns a list of detected product dicts.

    Detection strategy (in priority order):
      1. build_detected_products  — object-anchored OCR pipeline (packaged goods)
      2. detect_fresh_products    — label/object/logo detection (fresh produce)
      3. detect_from_ocr          — keyword fallback over all annotation text
    Unverified products are passed through GPT normalization before returning.
    """
    if client is None:
        raise RuntimeError("Google Vision client is not initialized")
    try:
        jpeg_bytes = _convert_to_jpeg(image_bytes)
        img_w, img_h = _image_size(jpeg_bytes)
    except Exception as e:
        raise ValueError(f"Could not read image: {e}")

    image = vision.Image(content=jpeg_bytes)
    response = _vision_request(image)

    # Stage 1: packaged-goods pipeline
    products = build_detected_products(response, img_w, img_h)

    # Stage 2: fall back to fresh-produce detection if nothing was found
    if not products:
        print("OCR pipeline found no products — falling back to label detection")
        products = detect_fresh_products(response)

    # Stage 3: supplement with OCR keyword matches if result set is small
    if len(products) < 5:
        ocr_products = detect_from_ocr(response)
        existing_names = {p.name for p in products}
        for p in ocr_products:
            if p.name not in existing_names:
                products.append(p)

    # Stage 4: GPT normalization for any product not already verified by OpenFoodFacts
    normalized = []
    for p in products:
        if not p.is_verified:
            better_name, better_category = normalize_product_name(p.name, p.product_type)
            normalized.append(DetectedProduct(
                name=better_name,
                product_type=better_category,
                confidence=p.confidence,
                off_name=p.off_name,
                nutritional_info=p.nutritional_info,
                is_verified=p.is_verified,
            ))
        else:
            normalized.append(p)

    return [p.to_dict() for p in normalized]
