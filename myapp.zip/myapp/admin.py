from django.contrib import admin
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin
from .models import (
    Profile, UserGoal, Product, Recipe, RecipeIngredient,
    MealPlan, MealPlanItem, ShoppingList, Inventory,
    Scan, ScanItem, Feedback, SystemSettings
)

# 1. User Model Admin
admin.site.unregister(User)

@admin.register(User)
class MyUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff')
    search_fields = ('username', 'first_name', 'last_name', 'email')


# 2. User Profile Admin
@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'first_name', 'last_name', 'age', 'gender', 'weight')
    search_fields = ('user__username', 'user__first_name', 'user__last_name')

    # Helper methods to expose related User fields in the list view
    def get_first_name(self, obj):
        return obj.user.first_name
    get_first_name.short_description = 'First Name'

    def get_last_name(self, obj):
        return obj.user.last_name
    get_last_name.short_description = 'Last Name'


# 3. Domain Model Admins

@admin.register(UserGoal)
class UserGoalAdmin(admin.ModelAdmin):
    list_display = ('user', 'goal_type', 'daily_calories', 'diet_type')
    list_filter = ('goal_type', 'diet_type')


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'calories_100g')
    search_fields = ('name', 'category')
    list_filter = ('category',)


@admin.register(Recipe)
class RecipeAdmin(admin.ModelAdmin):
    list_display = ('title', 'difficulty', 'cook_time', 'servings')
    list_filter = ('difficulty', 'category')
    search_fields = ('title', 'description')


@admin.register(RecipeIngredient)
class RecipeIngredientAdmin(admin.ModelAdmin):
    list_display = ('recipe', 'product', 'amount', 'unit')
    list_filter = ('recipe', 'product')


@admin.register(MealPlan)
class MealPlanAdmin(admin.ModelAdmin):
    list_display = ('user', 'start_date', 'end_date', 'total_calories')


@admin.register(MealPlanItem)
class MealPlanItemAdmin(admin.ModelAdmin):
    list_display = ('meal_plan', 'recipe', 'day', 'meal_type')


@admin.register(ShoppingList)
class ShoppingListAdmin(admin.ModelAdmin):
    list_display = ('user', 'meal_plan', 'created_at')


@admin.register(Inventory)
class InventoryAdmin(admin.ModelAdmin):
    list_display = ('user', 'product', 'amount', 'unit', 'expiration_date')
    list_filter = ('user', 'expiration_date')


@admin.register(Scan)
class ScanAdmin(admin.ModelAdmin):
    list_display = ('id', 'created_at',)


@admin.register(ScanItem)
class ScanItemAdmin(admin.ModelAdmin):
    list_display = ('scan', 'name', 'confidence', 'quantity_guess')


@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ('user', 'recipe', 'rating')
    list_filter = ('rating',)


@admin.register(SystemSettings)
class SystemSettingsAdmin(admin.ModelAdmin):
    list_display = ('min_calories', 'max_calories', 'daily_ai_limit')

    # Prevent deletion of system-wide settings to protect calorie limit configuration
    def has_delete_permission(self, request, obj=None):
        return False
