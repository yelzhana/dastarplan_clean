import json
from openai import OpenAI
from datetime import timedelta
from django.utils import timezone
from django.conf import settings
from .models import Recipe, Product, RecipeIngredient, SystemSettings
from ddgs import DDGS

OPENAI_KEY = getattr(settings, 'OPENAI_API_KEY', None)
client = OpenAI(api_key=OPENAI_KEY)


# Block 1: Image Search

def fetch_recipe_image(query):
    """Search for a dish photo via DuckDuckGo Images."""
    try:
        search_query = f"{query} food photography recipe"
        ddgs = DDGS()
        results = ddgs.images(search_query, max_results=5)
        for r in results:
            image_url = r.get('image')
            if image_url:
                return image_url
        return None
    except Exception as e:
        print(f"Image search failed for {query}: {e}")
        return None


# Block 2: Recipe Validation

def check_recipe_exists_online(title: str, ingredients: list) -> tuple[bool, str]:
    """
    Verify that a recipe represents a real dish via GPT validation.
    Returns (is_real, reason).
    """
    try:
        ing_names = [i.get('name', '') for i in ingredients[:5]]
        ing_str = ", ".join(ing_names)

        validation_prompt = f"""Это реально существующее блюдо или выдуманная комбинация?
Название: "{title}"
Основные ингредиенты: {ing_str}

Ответь ТОЛЬКО JSON:
{{"is_real": true/false, "reason": "объяснение"}}

Примеры нереальных блюд: "Паста с колой", "Торт из огурцов и рыбы", "Суп из шоколада с курицей"
Примеры реальных: "Борщ", "Паста карбонара", "Греческий салат", "Плов с бараниной"
"""
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": validation_prompt}],
            max_tokens=100,
            temperature=0,
        )
        result = json.loads(response.choices[0].message.content.strip())
        return result.get('is_real', True), result.get('reason', '')

    except Exception as e:
        print(f"⚠️ Recipe existence check failed: {e}")
        return True, "Check unavailable"


def validate_recipe_for_profile(data: dict, user_profile) -> tuple[bool, str]:
    """
    Check whether a recipe is compatible with the user's dietary profile.
    Returns (approved, reason).
    """
    if not user_profile:
        return True, "No profile"

    try:
        allergies = getattr(user_profile, 'allergies', '') or ''
        preferences = getattr(user_profile, 'preferences', '') or ''
        daily_target = getattr(user_profile, 'daily_target', 2000) or 2000
        meals_per_day = getattr(user_profile, 'meals_per_day', 3) or 3

        # Target calories per single meal
        calories_per_meal = daily_target / meals_per_day
        recipe_calories = data.get('nutrition', {}).get('calories', 0)

        ing_names = [i.get('name', '') for i in data.get('ingredients', [])]
        ing_str = ", ".join(ing_names)

        validation_prompt = f"""Проверь соответствие рецепта профилю пользователя.

РЕЦЕПТ:
- Название: {data.get('title')}
- Ингредиенты: {ing_str}
- Калории: {recipe_calories} ккал
- Категория: {data.get('category')}

ПРОФИЛЬ ПОЛЬЗОВАТЕЛЯ:
- Аллергии: {allergies if allergies else 'нет'}
- Диетические предпочтения: {preferences if preferences else 'нет'}
- Калорий на приём пищи: ~{int(calories_per_meal)} ккал
- Отклонение допустимо: ±40%

ПРОВЕРЬ:
1. Нет ли запрещённых ингредиентов (аллергены, нарушение диеты)
2. Укладываются ли калории в норму (±40% от {int(calories_per_meal)})

Ответь ТОЛЬКО JSON:
{{"approved": true/false, "reason": "причина если не одобрен"}}
"""
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": validation_prompt}],
            max_tokens=150,
            temperature=0,
        )
        result = json.loads(response.choices[0].message.content.strip())
        return result.get('approved', True), result.get('reason', '')

    except Exception as e:
        print(f"⚠️ Profile validation failed: {e}")
        return True, "Validation unavailable"


# Block 3: AI Rate Limiting & Diversity Helpers

def check_ai_limit():
    """Return True if the project-wide daily AI generation limit has not been reached."""
    settings_obj = SystemSettings.objects.first()
    limit = settings_obj.daily_ai_limit if settings_obj else 200
    last_24h = timezone.now() - timedelta(days=1)
    return Recipe.objects.filter(created_at__gte=last_24h).count() < limit


def get_recent_recipe_titles(limit=30):
    """Return titles of the most recently created recipes to avoid repetition."""
    return list(Recipe.objects.order_by('-created_at')[:limit].values_list('title', flat=True))


# Block 4: Recipe Generation

def generate_recipe_with_ai(ingredients_list=None, user_profile=None):
    """
    Full AI recipe generation pipeline:
      1. Build a context-aware GPT prompt using inventory, profile, and recent history.
      2. Validate the result is a real dish.
      3. Validate compatibility with the user's dietary profile.
      4. Normalise ingredient names via a second GPT call.
      5. Persist the recipe and its ingredients to the database.
    """
    if not check_ai_limit():
        return {"error": "Daily AI limit reached"}

    # Gather available products from the database
    db_products = list(Product.objects.values_list('name', flat=True)[:150])
    db_products_str = ", ".join(db_products)

    # Recent titles used to discourage duplicate recipes
    recent_titles = get_recent_recipe_titles(30)
    recent_str = ", ".join(recent_titles) if recent_titles else "none"

    # Build profile context block for the prompt
    profile_info = ""
    if user_profile:
        goal_map = {
            'lose_weight': 'похудение',
            'maintain': 'поддержание веса',
            'gain_weight': 'набор массы',
        }
        goal = goal_map.get(getattr(user_profile, 'goal_type', ''), 'поддержание веса')
        profile_info = f"""
ПРОФИЛЬ ПОЛЬЗОВАТЕЛЯ:
- Цель: {goal}
- Калорий в день: {int(getattr(user_profile, 'daily_target', 2000) or 2000)}
- Приёмов пищи: {getattr(user_profile, 'meals_per_day', 3) or 3}
- Аллергии: {getattr(user_profile, 'allergies', '') or 'нет'}
- Диета: {getattr(user_profile, 'preferences', '') or 'нет ограничений'}
"""

    input_ingredients = ", ".join(ingredients_list) if ingredients_list else "разнообразные полезные продукты"

    # Pick the least-used meal category from the last 6 approved recipes
    last_categories = list(
        Recipe.objects.filter(is_approved=True)
        .order_by('-created_at')[:6]
        .values_list('category', flat=True)
    )
    all_cats = ['Завтрак', 'Обед', 'Ужин']
    cat_counts = {c: last_categories.count(c) for c in all_cats}
    preferred_category = min(cat_counts, key=cat_counts.get)

    prompt = f"""Ты — профессиональный диетолог и шеф-повар.
Создай РЕАЛЬНО СУЩЕСТВУЮЩИЙ рецепт категории "{preferred_category}".

ДОСТУПНЫЕ ПРОДУКТЫ: {input_ingredients}
ПРОДУКТЫ В СИСТЕМЕ: {db_products_str}

ПРАВИЛА:
1. Рецепт ДОЛЖЕН быть реально существующим блюдом (борщ, плов, паста карбонара, греческий салат и т.д.)
2. НЕ ПРИДУМЫВАЙ абсурдные комбинации (паста с колой, торт из огурцов и т.д.)
3. НЕ ПОВТОРЯЙ: [{recent_str}]
4. ИСПОЛЬЗУЙ преимущественно доступные продукты пользователя
5. КАТЕГОРИЯ строго: {preferred_category}
6. Оцени risk_score (0-100): высокий если аллергены, много сахара/жира/соли
{profile_info}

ВЕРНИ ТОЛЬКО JSON (без markdown):
{{
    "title": "Реальное название блюда",
    "description": "Шаг 1: ...\\nШаг 2: ...\\nШаг 3: ...",
    "cook_time": 30,
    "difficulty": "Легко",
    "category": "{preferred_category}",
    "servings": 2,
    "risk_score": 10,
    "violations": [],
    "nutrition": {{
        "calories": 350,
        "protein": 25,
        "fat": 10,
        "carbs": 40
    }},
    "ingredients": [
        {{ "name": "название", "amount": 150, "unit": "г" }}
    ]
}}"""

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "Отвечай ТОЛЬКО валидным JSON без markdown. Только реально существующие блюда."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.8,
            max_tokens=1000,
        )

        raw_content = response.choices[0].message.content.strip()
        # Strip markdown code fences if the model wraps the JSON
        if raw_content.startswith('```'):
            raw_content = raw_content.split('```')[1]
            if raw_content.startswith('json'):
                raw_content = raw_content[4:]

        data = json.loads(raw_content)

        # Moderation pipeline
        is_approved = True
        moderation_notes = []

        # Check 1: required fields present
        if not data.get('title') or not data.get('description'):
            is_approved = False
            moderation_notes.append("Missing title or description")

        if len(data.get('ingredients', [])) < 2:
            is_approved = False
            moderation_notes.append("Too few ingredients")

        # Check 2: AI risk score threshold
        if data.get('risk_score', 0) > 70:
            is_approved = False
            moderation_notes.append(f"High risk score: {data.get('risk_score')}/100")

        # Check 3: real-world dish verification
        if is_approved:
            recipe_is_real, real_reason = check_recipe_exists_online(
                data['title'], data.get('ingredients', [])
            )
            if not recipe_is_real:
                is_approved = False
                moderation_notes.append(f"Not a real dish: {real_reason}")
            else:
                print(f"✅ Рецепт реален: {real_reason}")

        # Check 4: user profile compatibility
        if is_approved and user_profile:
            profile_ok, profile_reason = validate_recipe_for_profile(data, user_profile)
            if not profile_ok:
                is_approved = False
                moderation_notes.append(f"Profile mismatch: {profile_reason}")
            else:
                print(f"✅ Профиль OK: {profile_reason}")

        print(f"{'✅ Одобрен' if is_approved else '❌ Не одобрен'}: {data['title']}")
        if moderation_notes:
            print(f"   Причины: {'; '.join(moderation_notes)}")

        # Fetch a representative dish photo
        image_url = fetch_recipe_image(data['title'])

        # Persist the recipe record
        recipe = Recipe.objects.create(
            title=data['title'],
            description=data['description'],
            cook_time=data.get('cook_time', 30),
            difficulty=data.get('difficulty', 'Легко'),
            category=data.get('category', preferred_category),
            servings=data.get('servings', 2),
            nutrition_json=data.get('nutrition', {}),
            calories=data.get('nutrition', {}).get('calories', 0),
            image_url=image_url,
            is_approved=True,
            risk_score=data.get('risk_score', 0),
            violations=data.get('violations', []) + moderation_notes,
        )

        # Normalise ingredient names to simple Russian common names via GPT
        raw_ingredients = data.get('ingredients', [])
        if raw_ingredients:
            try:
                ing_names = [i.get('name', '') for i in raw_ingredients]
                normalize_prompt = f"""Нормализуй названия продуктов — приведи к простому бытовому названию на русском.
        Например: "куриное филе" → "курица", "картофель по-деревенски" → "картофель", "оливковое масло Extra Virgin" → "оливковое масло"

        Продукты: {ing_names}

        Верни ТОЛЬКО JSON список в том же порядке:
        ["название1", "название2", ...]"""

                norm_response = client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[{"role": "user", "content": normalize_prompt}],
                    max_tokens=200,
                    temperature=0,
                )
                normalized_names = json.loads(norm_response.choices[0].message.content.strip())
                for i, ing in enumerate(raw_ingredients):
                    if i < len(normalized_names):
                        ing['name'] = normalized_names[i]
            except Exception as e:
                print(f"⚠️ Ingredient normalisation failed: {e}")

        # Persist ingredients, creating Product records for unknown items
        for ing in raw_ingredients:
            product_name = ing.get('name', '').lower().strip()
            if not product_name:
                continue

            product = Product.objects.filter(name=product_name).first()
            if not product:
                product = Product.objects.create(
                    name=product_name,
                    category='AI Generated',
                    calories_100g=0,
                    protein_100g=0,
                    fat_100g=0,
                    carbs_100g=0,
                )

            RecipeIngredient.objects.create(
                recipe=recipe,
                product=product,
                amount=ing.get('amount', 100),
                unit=ing.get('unit', 'г'),
                name=product_name,
            )

        return recipe

    except json.JSONDecodeError as e:
        print(f"JSON parse error: {e}")
        return {"error": f"Parse error: {e}"}
    except Exception as e:
        print(f"Generation error: {e}")
        return {"error": str(e)}
