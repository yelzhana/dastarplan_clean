from rest_framework import viewsets, filters, status, parsers, serializers
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated, AllowAny, IsAdminUser
from rest_framework.decorators import action
from django_filters.rest_framework import DjangoFilterBackend
from django.contrib.admin.models import LogEntry
from django.utils import timezone
from .services import generate_recipe_with_ai
from .models import (
    Product, Inventory, SystemSettings, Profile, UserGoal,
    Recipe, MealPlan, MealPlanItem, ShoppingList, Category,
    Scan, ScanItem, Feedback
)
from .serializers import (
    ProductSerializer, InventorySerializer, SystemSettingsSerializer,
    ProfileSerializer, UserGoalSerializer, RecipeSerializer,
    MealPlanSerializer, MealPlanItemSerializer, ShoppingListSerializer,
    CategorySerializer, ScanSerializer, FeedbackSerializer, AdminLogSerializer
)

# Register HEIC/HEIF support if pillow-heif is installed
try:
    from pillow_heif import register_heif_opener
    register_heif_opener()
except ImportError:
    pass


# Block 1: AI Nutrition Helper

def get_nutrition_from_ai(product_name: str) -> dict:
    """
    Fetch per-100g macronutrient data for a product via GPT.
    Called on manual product creation and during CV scan processing.
    """
    try:
        import json
        from openai import OpenAI
        from django.conf import settings
        client_ai = OpenAI(api_key=settings.OPENAI_API_KEY)
        prompt = f"""Дай примерное КБЖУ на 100г продукта: "{product_name}"
Верни ТОЛЬКО JSON без пояснений:
{{"calories_100g": число, "protein_100g": число, "fat_100g": число, "carbs_100g": число, "category": "Овощи/Фрукты/Мясо/Молочное/Крупы/Соусы/Напитки/Сладости/Другое"}}"""
        response = client_ai.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=80,
            temperature=0,
        )
        result = json.loads(response.choices[0].message.content.strip())
        return {
            'calories_100g': float(result.get('calories_100g', 0)),
            'protein_100g':  float(result.get('protein_100g', 0)),
            'fat_100g':      float(result.get('fat_100g', 0)),
            'carbs_100g':    float(result.get('carbs_100g', 0)),
            'category':      result.get('category', 'Другое'),
        }
    except Exception as e:
        print(f"⚠️ AI nutrition error: {e}")
        return {'calories_100g': 0, 'protein_100g': 0, 'fat_100g': 0, 'carbs_100g': 0, 'category': 'Другое'}


# Block 2: Product & Inventory

class ProductViewSet(viewsets.ModelViewSet):
    """CRUD for food products. Returns existing record if a duplicate name is detected."""
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [AllowAny]
    search_fields = ['name', 'category']

    def perform_create(self, serializer):
        product_name = self.request.data.get('name', '').strip().lower()

        # Return existing product to avoid duplicates
        existing = Product.objects.filter(name=product_name).first()
        if existing:
            serializer.instance = existing
            return

        # Enrich with AI-generated nutrition data
        nutrition = get_nutrition_from_ai(product_name)
        serializer.save(
            calories_100g=nutrition['calories_100g'],
            protein_100g=nutrition['protein_100g'],
            fat_100g=nutrition['fat_100g'],
            carbs_100g=nutrition['carbs_100g'],
            category=self.request.data.get('category') or nutrition['category'],
        )

        nutrition = get_nutrition_from_ai(product_name)
        serializer.save(
            calories_100g=nutrition['calories_100g'],
            protein_100g=nutrition['protein_100g'],
            fat_100g=nutrition['fat_100g'],
            carbs_100g=nutrition['carbs_100g'],
            category=self.request.data.get('category') or nutrition['category'],
        )


class InventoryViewSet(viewsets.ModelViewSet):
    """Manage the current user's ingredient inventory."""
    serializer_class = InventorySerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Inventory.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


# Block 3: Recipes

class RecipeViewSet(viewsets.ModelViewSet):
    """
    Read/write access to approved recipes.
    Additional actions: pending list, approve, reject.
    """
    serializer_class = RecipeSerializer

    def get_queryset(self):
        return Recipe.objects.filter(is_approved=True).order_by('-created_at')

    @action(detail=False, methods=['get'])
    def pending(self, request):
        """Return recipes awaiting moderation, ordered by risk score descending."""
        pending_recipes = Recipe.objects.filter(is_approved=False).order_by('-risk_score')
        page = self.paginate_queryset(pending_recipes)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(pending_recipes, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        """Mark a recipe as approved."""
        try:
            recipe = Recipe.objects.get(pk=pk)
            recipe.is_approved = True
            recipe.save()
            return Response({'status': 'Рецепт одобрен'})
        except Recipe.DoesNotExist:
            return Response({'error': 'Рецепт не найден'}, status=404)

    @action(detail=True, methods=['delete'])
    def reject(self, request, pk=None):
        """Permanently delete a rejected recipe."""
        try:
            recipe = Recipe.objects.get(pk=pk)
            recipe.delete()
            return Response({'status': 'Рецепт удалён'})
        except Recipe.DoesNotExist:
            return Response({'error': 'Рецепт не найден'}, status=404)


# Block 4: User Profile & Goals

class ProfileViewSet(viewsets.ModelViewSet):
    serializer_class = ProfileSerializer
    permission_classes = [AllowAny]

    def get_queryset(self):
        return Profile.objects.all()


class UserGoalViewSet(viewsets.ModelViewSet):
    """Manage nutritional goals scoped to the current user."""
    serializer_class = UserGoalSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return UserGoal.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


# Block 5: Meal Planning

class MealPlanViewSet(viewsets.ModelViewSet):
    """Manage meal plans belonging to the current user."""
    serializer_class = MealPlanSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return MealPlan.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class MealPlanItemViewSet(viewsets.ModelViewSet):
    """Individual recipe slots within the current user's meal plans."""
    serializer_class = MealPlanItemSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return MealPlanItem.objects.filter(meal_plan__user=self.request.user)


class ShoppingListViewSet(viewsets.ModelViewSet):
    """Shopping lists owned by the current user."""
    serializer_class = ShoppingListSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return ShoppingList.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


# Block 6: System & Categories

class SystemSettingsViewSet(viewsets.ReadOnlyModelViewSet):
    """Read-only access to project-wide system settings."""
    queryset = SystemSettings.objects.all()
    serializer_class = SystemSettingsSerializer


class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer


# Block 7: CV Scanning

class ScanViewSet(viewsets.ModelViewSet):
    """
    Handle image uploads and run the full CV pipeline:
    detect products → fetch nutrition → update inventory.
    """
    queryset = Scan.objects.all()
    serializer_class = ScanSerializer
    parser_classes = [parsers.MultiPartParser, parsers.FormParser]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        # Read image bytes before saving so the file pointer is not exhausted
        image_file  = self.request.FILES.get('image')
        image_bytes = image_file.read() if image_file else None
        scan = serializer.save()

        try:
            from .cv_service import analyze_image_bytes
            if image_bytes:
                detected = analyze_image_bytes(image_bytes)
                scan.detected_items = detected
                scan.save()

                for item in detected:
                    product_name = (item.get('off_name') or item.get('name') or '').strip().lower()
                    if not product_name:
                        continue

                    nutr = item.get('nutritional_info') or {}

                    # Fall back to AI nutrition if CV pipeline returned no macros
                    if not nutr.get('calories_100g'):
                        nutr = get_nutrition_from_ai(product_name)

                    product = Product.objects.filter(name=product_name).first()
                    if not product:
                        product = Product.objects.create(
                            name=product_name,
                            category='AI Generated',
                            calories_100g=0,
                            protein_100g=0,
                            fat_100g=0,
                            carbs_100g=0,
                        )

                    # Backfill nutrition data for products previously stored with zeroes
                    if product.calories_100g == 0 and nutr.get('calories_100g'):
                        product.calories_100g = nutr.get('calories_100g', 0)
                        product.protein_100g  = nutr.get('protein_100g', 0)
                        product.fat_100g      = nutr.get('fat_100g', 0)
                        product.carbs_100g    = nutr.get('carbs_100g', 0)
                        product.save()

                    ScanItem.objects.create(
                        scan=scan,
                        product=product,
                        name=product_name,
                        confidence=item.get('confidence', 0.0),
                        quantity_guess=1.0,
                        unit_guess='шт',
                    )

                    # Add detected product to the user's inventory
                    if self.request.user.is_authenticated:
                        Inventory.objects.update_or_create(
                            user=self.request.user,
                            product=product,
                            defaults={'amount': 1.0, 'unit': 'шт'}
                        )

        except Exception as e:
            print(f"⚠️ CV error: {e}")
            scan.detected_items = [{"error": str(e)}]
            scan.save()

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        instance = serializer.instance
        return Response(self.get_serializer(instance).data, status=status.HTTP_201_CREATED)


# Block 8: Feedback

class FeedbackViewSet(viewsets.ModelViewSet):
    """User ratings and comments for recipes."""
    serializer_class = FeedbackSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Feedback.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


# Block 9: Shopping List Calculation

def normalize_category(category: str) -> str:
    """Map raw product category strings to a fixed set of Russian display categories."""
    cat = (category or '').lower().strip()
    if any(x in cat for x in ['meat', 'мясо', 'chicken', 'beef', 'курица', 'говяд']):
        return 'Мясо'
    if any(x in cat for x in ['vegetable', 'овощ', 'фрукт', 'fruit']):
        return 'Овощи'
    if any(x in cat for x in ['dairy', 'молоч', 'milk', 'cheese', 'сыр']):
        return 'Молочное'
    if any(x in cat for x in ['grain', 'крупы', 'pasta', 'рис', 'bread', 'хлеб']):
        return 'Крупы'
    if any(x in cat for x in ['sauce', 'соус', 'pesto', 'кетчуп']):
        return 'Соусы'
    if any(x in cat for x in ['drink', 'напит', 'cola', 'juice', 'сок']):
        return 'Напитки'
    if any(x in cat for x in ['ai generated', 'другое', 'other']):
        return 'Другое'
    return category


class ShoppingListCalculateView(APIView):
    """
    GET /api/shopping-list/calculate/
    Compute missing ingredients for the user's latest meal plan
    by diffing required recipe ingredients against current inventory.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user

        # Fetch the user's most recent meal plan
        latest_plan = MealPlan.objects.filter(user=user).last()
        if not latest_plan:
            return Response({"items": [], "message": "Нет активного плана питания"})

        # Aggregate all ingredient requirements across the plan
        from .models import RecipeIngredient
        plan_items = MealPlanItem.objects.filter(meal_plan=latest_plan).select_related('recipe')
        needed = {}  # {product_id: {name, amount, unit, category}}

        for plan_item in plan_items:
            ingredients = RecipeIngredient.objects.filter(
                recipe=plan_item.recipe
            ).select_related('product')
            for ing in ingredients:
                pid = ing.product.id
                if pid not in needed:
                    needed[pid] = {
                        'product_id': pid,
                        'name':       ing.product.name,
                        'amount':     ing.amount,
                        'unit':       ing.unit,
                        'category':   ing.product.category,
                    }
                else:
                    needed[pid]['amount'] += ing.amount

        # Build a lookup of what the user already has
        inventory = Inventory.objects.filter(user=user).select_related('product')
        have_ids  = set(inv.product.id for inv in inventory)
        have      = {inv.product.id: inv.amount for inv in inventory}

        # Collect items that are completely absent from inventory
        missing = []
        for pid, item in needed.items():
            have_amount = have.get(pid, 0)
            need_amount = item['amount']
            if pid not in have_ids:
                missing.append({
                    'product_id':    pid,
                    'name':          item['name'],
                    'amount_needed': round(need_amount - have_amount, 1),
                    'unit':          item['unit'],
                    'category':      item['category'] or 'Другое',
                })

        # Group missing items by normalised category
        categories = {}
        for item in missing:
            cat = item['category']
            if cat not in categories:
                categories[cat] = []
            categories[cat].append(item)

        normalized_categories = {}
        for cat, items in categories.items():
            norm_cat = normalize_category(cat)
            if norm_cat not in normalized_categories:
                normalized_categories[norm_cat] = []
            normalized_categories[norm_cat].extend(items)

        result = [
            {'category': cat, 'items': items}
            for cat, items in sorted(normalized_categories.items())
        ]
        return Response({'categories': result, 'total_missing': len(missing)})


# Block 10: AI Recipe Generation

class GenerateRecipeView(APIView):
    """
    POST /api/generate-recipe/
    Trigger AI recipe generation using the user's inventory as input.
    Falls back to a default ingredient set if the inventory is empty.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        ingredients = request.data.get('ingredients', [])
        if not ingredients:
            inventory    = Inventory.objects.filter(user=request.user).select_related('product')
            ingredients  = [item.product.name for item in inventory]
        if not ingredients:
            ingredients = ['курица', 'рис', 'овощи']

        result = generate_recipe_with_ai(ingredients, getattr(request.user, 'profile', None))
        if isinstance(result, dict) and "error" in result:
            status_code = 429 if "limit" in result["error"] else 500
            return Response(result, status=status_code)

        serializer = RecipeSerializer(result)
        return Response(serializer.data, status=201)


# Block 11: Admin Logs & Dashboard

class LogEntrySerializer(serializers.ModelSerializer):
    """Serializer for Django admin log entries with human-readable action type."""
    user_name   = serializers.CharField(source='user.username', read_only=True)
    action_type = serializers.SerializerMethodField()

    class Meta:
        model  = LogEntry
        fields = ['id', 'action_time', 'user_name', 'content_type',
                  'object_repr', 'action_flag', 'action_type', 'change_message']

    def get_action_type(self, obj):
        if obj.is_addition(): return "Добавление"
        if obj.is_change():   return "Изменение"
        if obj.is_deletion(): return "Удаление"
        return "Действие"


class AdminLogViewSet(viewsets.ReadOnlyModelViewSet):
    """Read-only view of the 50 most recent Django admin log entries."""
    queryset = LogEntry.objects.all().order_by('-action_time')[:50]
    serializer_class = AdminLogSerializer
    permission_classes = []


class DashboardStatsView(APIView):
    """
    GET /api/dashboard/stats/?days=7|30|90|all
    Aggregate platform metrics filtered by the requested time window.
    """
    def get(self, request):
        from django.contrib.auth.models import User
        from django.utils import timezone
        from datetime import timedelta
        now = timezone.now()

        # Parse the ?days= query parameter
        days_param = request.query_params.get('days', '7')
        if days_param == 'all':
            date_from = None
        else:
            try:
                days = int(days_param)
            except ValueError:
                days = 7
            date_from = now - timedelta(days=days)

        # Apply date filter to all querysets
        scan_qs   = Scan.objects.all()
        recipe_qs = Recipe.objects.filter(is_approved=True)
        meal_qs   = MealPlan.objects.all()

        if date_from:
            scan_qs   = scan_qs.filter(created_at__gte=date_from)
            recipe_qs = recipe_qs.filter(created_at__gte=date_from)
            meal_qs   = meal_qs.filter(created_at__gte=date_from)

        total_users    = User.objects.count()
        total_recipes  = recipe_qs.count()
        total_scans    = scan_qs.count()
        total_shopping = meal_qs.count()

        # Build per-day scan activity for the selected window
        if date_from:
            activity_days = (now - date_from).days + 1
        else:
            activity_days = 90  # cap "all time" chart at 90 days

        activity = []
        for i in range(activity_days - 1, -1, -1):
            day       = now - timedelta(days=i)
            day_start = day.replace(hour=0, minute=0, second=0, microsecond=0)
            day_end   = day_start + timedelta(days=1)
            count = Scan.objects.filter(
                created_at__gte=day_start,
                created_at__lt=day_end
            ).count()
            activity.append({
                "date":  day_start.strftime("%d %b"),
                "scans": count
            })

        # User goal distribution
        from .models import UserProfile
        goals = UserProfile.objects.values('goal').annotate(
            count=Count('goal')
        )

        # Top recipes by meal plan usage
        top_recipes = Recipe.objects.filter(is_approved=True).annotate(
            usage=Count('mealplanitem')
        ).order_by('-usage')[:5].values('name', 'usage')

        return Response({
            "total_users":    total_users,
            "total_recipes":  total_recipes,
            "total_scans":    total_scans,
            "total_shopping": total_shopping,
            "activity":       activity,
            "goals":          list(goals),
            "top_recipes":    list(top_recipes),
            "period_days":    days_param,
        })
