from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.permissions import AllowAny, IsAuthenticated
from .models import Profile
from .serializers import ProfileSerializer


class RegisterView(APIView):
    """
    POST /api/auth/register/
    Create a new user account.
    Request body: { "email": "...", "password": "..." }
    Response:     { "token": "...", "user_id": ..., "email": "..." }
    """
    permission_classes = [AllowAny]

    def post(self, request):
        email    = request.data.get('email', '').strip().lower()
        password = request.data.get('password', '')

        # Input validation
        if not email or not password:
            return Response(
                {'error': 'Email и пароль обязательны'},
                status=status.HTTP_400_BAD_REQUEST
            )
        if len(password) < 6:
            return Response(
                {'error': 'Пароль должен быть минимум 6 символов'},
                status=status.HTTP_400_BAD_REQUEST
            )
        if User.objects.filter(email=email).exists():
            return Response(
                {'error': 'Пользователь с таким email уже существует'},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Create user with email as username
        user = User.objects.create_user(
            username=email,
            email=email,
            password=password
        )

        token, _ = Token.objects.get_or_create(user=user)
        return Response({
            'token':   token.key,
            'user_id': user.id,
            'email':   user.email,
        }, status=status.HTTP_201_CREATED)


class LoginView(APIView):
    """
    POST /api/auth/login/
    Authenticate an existing user and return a token.
    Request body: { "email": "...", "password": "..." }
    Response:     { "token": "...", "user_id": ..., "email": "...", "has_profile": true/false }
    """
    permission_classes = [AllowAny]

    def post(self, request):
        email    = request.data.get('email', '').strip().lower()
        password = request.data.get('password', '')

        if not email or not password:
            return Response(
                {'error': 'Email и пароль обязательны'},
                status=status.HTTP_400_BAD_REQUEST
            )

        # username field stores the email value
        user = authenticate(username=email, password=password)
        if not user:
            return Response(
                {'error': 'Неверный email или пароль'},
                status=status.HTTP_401_UNAUTHORIZED
            )

        token, _  = Token.objects.get_or_create(user=user)
        has_profile = Profile.objects.filter(user=user).exists()

        return Response({
            'token':       token.key,
            'user_id':     user.id,
            'email':       user.email,
            'has_profile': has_profile,  # iOS uses this to decide whether to show onboarding
        }, status=status.HTTP_200_OK)


class MeView(APIView):
    """
    GET /api/auth/me/
    Return the profile of the currently authenticated user.
    Header: Authorization: Token <token>
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            profile    = Profile.objects.get(user=request.user)
            serializer = ProfileSerializer(profile, context={'request': request})
            return Response({
                'user_id':     request.user.id,
                'email':       request.user.email,
                'profile':     serializer.data,
                'has_profile': True,
            })
        except Profile.DoesNotExist:
            return Response({
                'user_id':     request.user.id,
                'email':       request.user.email,
                'profile':     None,
                'has_profile': False,
            })


class SaveProfileView(APIView):
    """
    POST /api/auth/profile/
    Persist onboarding data and create/update the user's Profile and UserGoal.
    Header: Authorization: Token <token>
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        data = request.data

        # Map iOS display values to internal DB constants
        goal_map = {
            'Похудение':            'lose_weight',
            'Поддержание веса':     'maintain',
            'Набор мышечной массы': 'gain_weight',
        }
        activity_map = {
            'Малоподвижность':     'sedentary',
            'Умеренная активность': 'moderate',
            'Высокая активность':  'active',
        }
        meals_map = {
            '1–2 приёма пищи':        2,
            '3 приёма пищи':          3,
            '4 приёма пищи':          4,
            '5 и более приёмов пищи': 5,
        }

        # Safe numeric parsing
        try:
            age = int(data.get('age', 0))
        except (ValueError, TypeError):
            age = 0
        try:
            weight = float(data.get('weight', 0))
        except (ValueError, TypeError):
            weight = 0.0
        try:
            height = float(data.get('height', 0))
        except (ValueError, TypeError):
            height = 0.0

        activity_level = activity_map.get(data.get('activity', ''), 'sedentary')
        meals_per_day  = meals_map.get(data.get('meals', ''), 3)

        # Mifflin-St Jeor BMR calculation (mirrors iOS logic)
        gender = data.get('gender', '')
        if gender == 'Женщина':
            bmr = 10 * weight + 6.25 * height - 5 * age - 161
        else:
            bmr = 10 * weight + 6.25 * height - 5 * age + 5

        multipliers  = {'sedentary': 1.2, 'moderate': 1.375, 'active': 1.55}
        daily_target = bmr * multipliers.get(activity_level, 1.2)

        # Combine dietary restrictions into a single string
        allergies   = data.get('allergies', '')
        diets       = data.get('diets', [])
        preferences = ', '.join(diets) if isinstance(diets, list) else diets

        # Create or update Profile
        profile, created = Profile.objects.update_or_create(
            user=user,
            defaults={
                'first_name':     data.get('name', ''),
                'age':            age,
                'gender':         gender,
                'weight':         weight,
                'height':         height,
                'activity_level': activity_level,
                'cooking_level':  'medium',
                'daily_target':   daily_target,
                'meals_per_day':  meals_per_day,
                'allergies':      allergies,
                'preferences':    preferences,
            }
        )

        # Keep the User first_name in sync
        user.first_name = data.get('name', '')
        user.save()

        # Create or update UserGoal
        from .models import UserGoal
        UserGoal.objects.update_or_create(
            user=user,
            defaults={
                'goal_type':      goal_map.get(data.get('goal', ''), 'maintain'),
                'daily_calories': int(daily_target),
                'diet_type':      preferences,
                'allergies':      allergies,
            }
        )

        serializer = ProfileSerializer(profile, context={'request': request})
        return Response(
            serializer.data,
            status=status.HTTP_201_CREATED if created else status.HTTP_200_OK
        )


class LogoutView(APIView):
    """
    POST /api/auth/logout/
    Invalidate the current auth token.
    Header: Authorization: Token <token>
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        request.user.auth_token.delete()
        return Response({'message': 'Вышли из системы'}, status=status.HTTP_200_OK)
