from django.db import models
from django.contrib.auth.models import User


# Block 1: Users & Goals

class Profile(models.Model):
    """Extended user profile storing physical attributes and dietary preferences."""
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=100, null=True, blank=True, verbose_name="Name")
    last_name = models.CharField(max_length=100, null=True, blank=True, verbose_name="Surname")
    age = models.IntegerField()
    gender = models.CharField(max_length=50)
    height = models.FloatField()
    weight = models.FloatField()
    allergies = models.TextField(blank=True)
    preferences = models.TextField(blank=True)
    cooking_level = models.CharField(max_length=50)
    activity_level = models.CharField(max_length=50)
    daily_target = models.FloatField()
    meals_per_day = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Profile: {self.user.username}"


class UserGoal(models.Model):
    """Tracks a user's active nutritional goal and dietary constraints."""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    goal_type = models.CharField(max_length=50)   # lose_weight | gain_weight | maintain
    daily_calories = models.IntegerField()
    diet_type = models.CharField(max_length=50)
    allergies = models.TextField(blank=True)


# Block 2: Product & Recipe Catalogue

class Product(models.Model):
    """A food product with per-100g macronutrient data."""
    name = models.CharField(max_length=255)
    category = models.CharField(max_length=100)
    calories_100g = models.FloatField()
    protein_100g = models.FloatField()
    fat_100g = models.FloatField()
    carbs_100g = models.FloatField()

    def __str__(self):
        return self.name


class Recipe(models.Model):
    """
    An AI-generated or user-submitted recipe.
    Includes moderation fields (is_approved, risk_score, violations)
    used by the admin AI moderation pipeline.
    """
    title = models.CharField(max_length=255)
    description = models.TextField()
    cook_time = models.IntegerField()
    difficulty = models.CharField(max_length=50)
    category = models.CharField(max_length=100)
    servings = models.IntegerField()
    nutrition_json = models.JSONField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    calories = models.IntegerField(default=0)
    image_url = models.URLField(max_length=500, null=True, blank=True)
    is_approved = models.BooleanField(default=False)        # Approved by moderator
    risk_score = models.IntegerField(default=0)             # 0–100 AI safety score
    violations = models.JSONField(default=list, blank=True) # e.g. ["Allergen", "High fat"]

    def __str__(self):
        return self.title


class RecipeIngredient(models.Model):
    """A single ingredient line in a recipe, linked to a Product for nutrition lookup."""
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE, related_name='ingredients')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    amount = models.FloatField()
    unit = models.CharField(max_length=20)
    name = models.CharField(max_length=255)


class Category(models.Model):
    """Top-level food category used for browsing and filtering."""
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


# Block 3: Meal Planning & Inventory

class MealPlan(models.Model):
    """A date-bounded meal plan generated for a user."""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()
    total_calories = models.IntegerField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)


class MealPlanItem(models.Model):
    """A single recipe slot within a meal plan (day + meal type)."""
    meal_plan = models.ForeignKey(MealPlan, on_delete=models.CASCADE, related_name='items')
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE)
    day = models.DateField()
    meal_type = models.CharField(max_length=50)  # breakfast | lunch | dinner


class ShoppingList(models.Model):
    """A shopping list derived from a meal plan."""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    meal_plan = models.ForeignKey(MealPlan, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)


class Inventory(models.Model):
    """Tracks the quantity of a product currently held by a user."""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    amount = models.FloatField()
    unit = models.CharField(max_length=20)
    updated_at = models.DateTimeField(auto_now=True)
    expiration_date = models.DateField(null=True, blank=True)


# Block 4: Scans & Feedback

class Scan(models.Model):
    """
    A CV scan session. Images are stored under media/scans/YYYY/MM/DD/.
    detected_items holds the raw JSON output from the Vision pipeline.
    """
    image = models.ImageField(upload_to='scans/%Y/%m/%d/')
    created_at = models.DateTimeField(auto_now_add=True)
    detected_items = models.JSONField(default=list, blank=True)

    def __str__(self):
        return f"Scan {self.id} - {self.created_at.strftime('%Y-%m-%d %H:%M')}"


class ScanItem(models.Model):
    """A single product detected within a scan, with confidence and quantity estimate."""
    scan = models.ForeignKey(Scan, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True)
    name = models.CharField(max_length=255)
    confidence = models.FloatField()
    quantity_guess = models.FloatField()
    unit_guess = models.CharField(max_length=20)


class Feedback(models.Model):
    """User rating and optional comment for a recipe."""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE)
    rating = models.IntegerField()
    comment = models.TextField(blank=True)


class SystemSettings(models.Model):
    """
    Singleton model for project-wide configuration.
    Only one instance is allowed; subsequent saves are silently ignored.
    """
    min_calories = models.IntegerField(default=0)
    max_calories = models.IntegerField(default=5000)
    daily_ai_limit = models.IntegerField(default=50)  # Max AI recipe generations per day

    def save(self, *args, **kwargs):
        # Enforce singleton: block creation of a second instance
        if not self.pk and SystemSettings.objects.exists():
            return
        super().save(*args, **kwargs)
